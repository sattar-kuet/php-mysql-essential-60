 <nav class="navbar navbar-default">
 	<div class="container-fluid">

 		

 		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
 			<ul class="nav navbar-nav navbar-right">
 				<li><a href="<?php echo $base_url;?>/cms/public/?>">Recent Post</a></li>
 				<li><a href="#">About Me</a></li>
 			</ul>
 		</div>
 	</div>
 </nav>