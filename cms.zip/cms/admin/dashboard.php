<?php $_COOKIE['title'] = 'Dashboard'; ?>
<?php include('../include/admin_header.php');?>



  <div class="wrapper">
    <!-- Sidebar Holder -->
    <?php include('partial/sidebar.php'); ?>

    <!-- Page Content Holder -->
    <div id="content">
      <!-- top nav bar -->
      <?php include('partial/top-nav.php');?>
      <div class="container">
               Dashboard
      </div>

    </div>
  </div>

<?php include('../include/footer.php');?>



